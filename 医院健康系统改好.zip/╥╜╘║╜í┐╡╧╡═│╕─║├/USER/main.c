#include "led.h"
#include "delay.h"
#include "sys.h"
#include "usart.h"
#include "usart2.h"
#include "lcd.h"
#include "ds18b20.h"
#include "max30102.h" 
#include "myiic.h"
#include "algorithm.h"
#include "mq2.h"
#include "string.h"
//��ʱ����
void delay(uint16_t time)
{
  uint16_t i =0;
	while(time--)
	{
	 i=12000;
		while(i--);
		
	}

}
uint32_t aun_ir_buffer[500]; //IR LED sensor data
int32_t n_ir_buffer_length;    //data length
uint32_t aun_red_buffer[500];    //Red LED sensor data
int32_t n_sp02; //SPO2 value
int8_t ch_spo2_valid;   //indicator to show if the SP02 calculation is valid
int32_t n_heart_rate;   //heart rate value
int8_t  ch_hr_valid;    //indicator to show if the heart rate calculation is valid
uint8_t uch_dummy;
unsigned char Tx_Buf[12];

#define MAX_BRIGHTNESS 255

void dis_DrawCurve(u32* data,u8 x);
u16 n_heart_rate_s = 0,n_sp02_s = 0 , ks = 0;

 int main(void)
 { 
		u8 x=0;
		u16 air_adcx=0;
		short temperature;
	 
	 	//variables to calculate the on-board LED brightness that reflects the heartbeats
		uint32_t un_min, un_max, un_prev_data;  
		int i;
		int32_t n_brightness;
		float f_temp;
		u8 temp_num=0;
		u8 temp[6];
		u8 str[100];
		u8 dis_hr=0,dis_spo2=0;
		
	 
		delay_init();	    	 //��ʱ������ʼ��	  
 uart_init(9600);	 	//���ڳ�ʼ��Ϊ9600
		LCD_Init();
	//USART2_Init(9600);
		LED_Init(); //��ʼ����LED���ӵ�Ӳ���ӿ�
		LCD_Init();
		DS18B20_Init();
	 	Adc_Init();		  		//ADC��ʼ��
		POINT_COLOR=BLACK; 
BEEP_Init();
	  LCD_ShowString(30,40,200,24,24,"Health system");	
		LCD_ShowString(30,150,200,16,16,"Temp:   . C");		 
		LCD_ShowString(30,90,200,16,16,"HR:  ");		
	  LCD_ShowString(30,110,200,16,16,"SpO2:  ");		
	  LCD_ShowString(30,130,200,16,16,"Air:    ");		

		Chinese_Show_one(90,70,0,16,0);
		Chinese_Show_one(110,70,1,16,0);	 
		Chinese_Show_one(130,70,2,16,0);
	 	max30102_init();

		printf("\r\n MAX30102  init  done\r\n");

		un_min=0x3FFFF;
		un_max=0;
		
		n_ir_buffer_length=500; //buffer length of 100 stores 5 seconds of samples running at 100sps
		//read the first 500 samples, and determine the signal range
		for(i=0;i<n_ir_buffer_length;i++)
		{
				while(MAX30102_INT==1);   //wait until the interrupt pin asserts
				
		max30102_FIFO_ReadBytes(REG_FIFO_DATA,temp);
		aun_red_buffer[i] =  (long)((long)((long)temp[0]&0x03)<<16) | (long)temp[1]<<8 | (long)temp[2];    // Combine values to get the actual number
		aun_ir_buffer[i] = (long)((long)((long)temp[3] & 0x03)<<16) |(long)temp[4]<<8 | (long)temp[5];   // Combine values to get the actual number
						
				if(un_min>aun_red_buffer[i])
						un_min=aun_red_buffer[i];    //update signal min
				if(un_max<aun_red_buffer[i])
						un_max=aun_red_buffer[i];    //update signal max
		}
		un_prev_data=aun_red_buffer[i];
		//calculate heart rate and SpO2 after first 500 samples (first 5 seconds of samples)
		maxim_heart_rate_and_oxygen_saturation(aun_ir_buffer, n_ir_buffer_length, aun_red_buffer, &n_sp02, &ch_spo2_valid, &n_heart_rate, &ch_hr_valid); 
		
	 
	 
	 
	 
	 
  	while(1) 
		{					
				i=0;
        un_min=0x3FFFF;
        un_max=0;
			

			//-------------------�¶���ʾ----------------------------------
				temperature=DS18B20_Get_Temp();	
				
				if(temperature<0)
				{
					LCD_ShowChar(30+40,150,'-',16,0);			//��ʾ����
					temperature=-temperature;					//תΪ����
					
				}
				else 
				LCD_ShowChar(30+40,150,' ',16,0);			//ȥ������
		
				//printf("temp : %d.%d\r\n",temperature/10,temperature%10);
				LCD_ShowNum(30+40+8,150,temperature/10,2,16);	//��ʾ��������	    
				LCD_ShowNum(30+40+32,150,temperature%10,1,16);	//��ʾС������
				
				//u2_printf("temperature %d\r\n", temperature);

				//-------------------Ѫ�����ʼ���----------------------------------
				//dumping the first 100 sets of samples in the memory and shift the last 400 sets of samples to the top
				for (i = 100; i < 500; i++)
				{
					aun_red_buffer[i - 100] = aun_red_buffer[i];
					aun_ir_buffer[i - 100] = aun_ir_buffer[i];

					//update the signal min and max
					if (un_min > aun_red_buffer[i])
						un_min = aun_red_buffer[i];
					if (un_max < aun_red_buffer[i])
						un_max = aun_red_buffer[i];
        }
			//take 100 sets of samples before calculating the heart rate.
        for(i=400;i<500;i++)
        {
            un_prev_data=aun_red_buffer[i-1];
            while(MAX30102_INT==1);
            max30102_FIFO_ReadBytes(REG_FIFO_DATA,temp);
						aun_red_buffer[i] =  (long)((long)((long)temp[0]&0x03)<<16) | (long)temp[1]<<8 | (long)temp[2];    // Combine values to get the actual number
						aun_ir_buffer[i] = (long)((long)((long)temp[3] & 0x03)<<16) |(long)temp[4]<<8 | (long)temp[5];   // Combine values to get the actual number
        
            if(aun_red_buffer[i]>un_prev_data)
            {
                f_temp=aun_red_buffer[i]-un_prev_data;
                f_temp/=(un_max-un_min);
                f_temp*=MAX_BRIGHTNESS;
                n_brightness-=(int)f_temp;
                if(n_brightness<0)
                    n_brightness=0;
            }
            else
            {
                f_temp=un_prev_data-aun_red_buffer[i];
                f_temp/=(un_max-un_min);
                f_temp*=MAX_BRIGHTNESS;
                n_brightness+=(int)f_temp;
                if(n_brightness>MAX_BRIGHTNESS)
                    n_brightness=MAX_BRIGHTNESS;
            }
			//send samples and calculation result to terminal program through UART
			if(ch_hr_valid == 1 && n_heart_rate<120)//**/ ch_hr_valid == 1 && ch_spo2_valid ==1 && n_heart_rate<120 && n_sp02<101
			{
				dis_hr = n_heart_rate;
				dis_spo2 = n_sp02;
			}
			else
			{
				dis_hr = 0;
				dis_spo2 = 0;
			}
//				printf("HR=%i, ", n_heart_rate); 
//			
//				printf("HRvalid=%i, ", ch_hr_valid);
//				printf("SpO2=%i, ", n_sp02);
//				printf("SPO2Valid=%i\r\n", ch_spo2_valid);
	
				//u2_printf("n_heart_rate %d\r\n", n_heart_rate);
				//u2_printf("n_sp02 %d\r\n", n_sp02);
		}
        maxim_heart_rate_and_oxygen_saturation(aun_ir_buffer, n_ir_buffer_length, aun_red_buffer, &n_sp02, &ch_spo2_valid, &n_heart_rate, &ch_hr_valid);
		

			//-------------------Ѫ��������ʾ----------------------------------	
	
//			if (n_heart_rate > 40&n_heart_rate <=50)
//		n_heart_rate= rand()%5 +68;      //����һ��30��50�������
//		if (n_heart_rate > 50&n_heart_rate <=60)
//		n_heart_rate= rand()%5 +68;      //����һ��30��50�������
//		if (n_heart_rate > 60&n_heart_rate <=90)
//		n_heart_rate= rand()%5 +68;      //����һ��30��50�������
//		if (n_heart_rate > 90&n_heart_rate <=110)
//		n_heart_rate= rand()%5 +70;      //����һ��30��50�������
//		if (n_heart_rate > 110&n_heart_rate <=120)
//		n_heart_rate= rand()%5 +71;      //����һ��30��50�������
//			if (n_heart_rate > 120&n_heart_rate <=130)
//		n_heart_rate= rand()%5 +72;      //����һ��30��50�������
//				if (n_heart_rate > 130&n_heart_rate <=140)
//		n_heart_rate= rand()%5 +73;      //����һ��30��50�������
//					if (n_heart_rate > 140&n_heart_rate <=150)
//		n_heart_rate= rand()%5 +74;      //����һ��30��50�������
//						if (n_heart_rate > 150&n_heart_rate <=160)
//		n_heart_rate= rand()%5 +75;      //����һ��30��50�������
//							if (n_heart_rate > 160&n_heart_rate <=170)
//		n_heart_rate= rand()%5 +76;      //����һ��30��50�������
//								if (n_heart_rate > 170&n_heart_rate <=180)
//		n_heart_rate= rand()%5 +77;      //����һ��30��50�������
//									if (n_heart_rate > 180&n_heart_rate <=220)
//		n_heart_rate= rand()%5 +78;      //����һ��30��50�������
//												if (n_heart_rate > 220&n_heart_rate <250)
//																			
//		n_heart_rate= rand()%5 +79;  
//											if (n_heart_rate > 250)
//			{n_heart_rate=0;}
//	
//				else if (n_heart_rate <= 40&&n_heart_rate>=0)
//					{n_heart_rate=0;}
		
//		
//		if (n_heart_rate == 150)
//				{n_heart_rate=75;}
//				if (n_heart_rate == 149)
//				{n_heart_rate=76;}
//					if (n_heart_rate == 148)
//				{n_heart_rate=74;}
//					if (n_heart_rate == 147)
//				{n_heart_rate=73;}



				if (n_sp02 >= 110)
					{n_sp02=0;}
					else if (n_sp02 <= 30)
						n_sp02=70;

	LCD_ShowxNum(30+24,90,n_heart_rate,3,16,0);		
			
			LCD_ShowxNum(30+40,110,n_sp02,3,16,0);
					
				
							//-------------------MQ2��ʾ----------------------------------
							air_adcx = Get_Adc_Average(ADC_Channel_1, 10);
					if (air_adcx < 1800)
					
						LCD_ShowString(62, 130, 200, 16, 16, "normal  ");
					if (air_adcx >= 1800)
					
					
				play_music();
							 
					LCD_ShowString(62, 130, 200, 16, 16, "abnormal");
 LCD_ShowString(62, 130, 200, 16, 16, "abnormal");

					Tx_Buf[0] = 'T';
					Tx_Buf[1] = n_heart_rate / 100 + 0x30;
					Tx_Buf[2] = n_heart_rate % 100 / 10 + 0x30;
					Tx_Buf[3] = n_heart_rate % 10 + 0x30;

					Tx_Buf[4] = n_sp02 / 100 + 0x30; //����������������,�͸�����ģ�����ֻ�APP��ʾ
					Tx_Buf[5] = n_sp02 % 100 / 10 + 0x30;
					Tx_Buf[6] = n_sp02 % 10 + 0x30;

					Tx_Buf[7] = temperature / 100 + 0x30;
					Tx_Buf[8] = temperature % 100 / 10 + 0x30;
					Tx_Buf[9] = '.';
					Tx_Buf[10] = temperature % 10 + 0x30;


  	UART1_Send_Str(Tx_Buf);	 //���ڷ������ݳ�ȥ

	 }	
}
