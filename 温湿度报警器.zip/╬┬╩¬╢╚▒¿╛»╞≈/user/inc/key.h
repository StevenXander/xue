#ifndef   __KEY_H__
#define   __KEY_H__


#include "stm32f4xx.h"


#define  KEY0       GPIO_ReadInputDataBit( GPIOC,  GPIO_Pin_8)
#define  KEY1       GPIO_ReadInputDataBit( GPIOC,  GPIO_Pin_9)
#define  KEY2 			GPIO_ReadInputDataBit( GPIOD,  GPIO_Pin_2)
              

u8 Key_Scan(void);

void Key_Pin_Init(void);

void Delay_Ms(u32 ms);
#endif





