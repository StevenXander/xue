#ifndef __HC_SR505_H__
#define	__HC_SR505_H__
#include "stm32f10x.h"
#include "gpio.h"

#define		HC_SR505			PAin(0)
#define		HC_SR505_PIN		GPIO_Pin_0
#define		HC_SR505PORT		GPIOA
#define		HC_SR505_CLKLINE    RCC_APB2Periph_GPIOA

extern void HC_SR505Configuration(void);
#endif
