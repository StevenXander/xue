#ifndef   __buzzer_H__
#define   __buzzer_H__


#include "stm32f4xx.h"

void buzzer_Init(void);
void Led_Pin_Init(void);


#define buzzer_off GPIO_SetBits(GPIOB,GPIO_Pin_8)
#define buzzer_on GPIO_ResetBits(GPIOB,GPIO_Pin_8)

#define LED_OFF GPIO_WriteBit (GPIOC, GPIO_Pin_0, Bit_SET)
#define  LED_ON GPIO_WriteBit (GPIOC, GPIO_Pin_0, Bit_RESET)

#endif
