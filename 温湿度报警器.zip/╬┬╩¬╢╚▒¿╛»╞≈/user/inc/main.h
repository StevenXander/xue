#ifndef   __MAIN_H__
#define   __MAIN_H__


#include "stm32f4xx.h"

#include "key.h"
#include "buzzer.h"

#define LED_OFF GPIO_WriteBit (GPIOC, GPIO_Pin_0, Bit_SET)
#define  LED_ON GPIO_WriteBit (GPIOC, GPIO_Pin_0, Bit_RESET)

#endif





